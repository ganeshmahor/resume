package com.ms.assignment.service;

import java.util.List;

import com.ms.assignment.domain.Order;

public interface OrderService {

	Order createOrder(Order inOrder);

	Order updateOrder(Order order);

	void deleteOrderById(Long id);

	void deleteOrderByUserId(Long userId);

	Order getOrderById(Long id);

	List<Order> getOrderByUserId(Long userId);



}