package com.ms.assignment.service;

import com.ms.assignment.domain.User;

public interface UserService {

    User getUserById(Long id);

	User getUserByFirstnameAndLastname(String firstName, String lastName);

	User getUserByEmail(String email);

    User createUser(User user);

    User updateUser(User user);

    void deleteUser(Long id);

}