package com.ms.assignment.controller;

import java.net.URI;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ms.assignment.domain.User;
import com.ms.assignment.service.OnCreate;
import com.ms.assignment.service.UserServiceImpl;

@RestController
@RequestMapping("/user")
@Validated
public class UserController {

	private @Autowired UserServiceImpl userService;

	@Validated(OnCreate.class)
	@PostMapping(value = "/", produces = { MediaType.APPLICATION_JSON_UTF8_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Object> createUser(@Valid @RequestBody User inUser, HttpServletRequest request,
			HttpServletResponse response) {

		User user = userService.createUser(inUser);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(user.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}


	@PutMapping(value = "/", produces = { MediaType.APPLICATION_JSON_UTF8_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Object> updateUser(@Valid @RequestBody User inUser, HttpServletRequest request,
			HttpServletResponse response) {
		User user = userService.updateUser(inUser);
		return ResponseEntity.accepted().build();
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable("id") @Min(5) long id, HttpServletRequest request,
			HttpServletResponse response) {

		return ResponseEntity.noContent().build();
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Object> getUserById(@PathVariable("id") @Min(1) long id, HttpServletRequest request,
			HttpServletResponse response) {
		User user = userService.getUserById(id);
		return ResponseEntity.ok(user);
		/*
		 * HttpHeaders headers = new HttpHeaders(); headers.add("Custom-Header", "foo");
		 * 
		 * return new ResponseEntity<>( "Custom header set", headers, HttpStatus.OK);
		 */
	}

	@GetMapping(value = "/email/{email}")
	public ResponseEntity<Object> getUserByEmail(@PathVariable("email") @Email String email, HttpServletRequest request,
			HttpServletResponse response) {
		User user = userService.getUserByEmail(email);
		return ResponseEntity.ok(user);
	}

	@GetMapping(value = "/name/{firstName}/{lastName}")
	public ResponseEntity<Object> getUserByFirstNameAndLastName(@PathVariable("firstName") @NotEmpty String firstName,
			@PathVariable("lastName") @NotEmpty String lastName, HttpServletRequest request,
			HttpServletResponse response) {
		User user = userService.getUserByFirstnameAndLastname(firstName, lastName);
		return ResponseEntity.ok(user);
	}

	/*
	 * @GetMapping(value = "") public ResponseEntity<Object>
	 * getUserByEmail(@RequestParam("email") @Email String email, HttpServletRequest
	 * request, HttpServletResponse response) { User user =
	 * userService.getUserByEmail(email); return ResponseEntity.ok(user); }
	 * 
	 * @GetMapping(value = "") public ResponseEntity<Object>
	 * getUserByFirstNameAndLastName(@RequestParam("firstName") @NotEmpty String
	 * firstName,
	 * 
	 * @RequestParam("lastName") @NotEmpty String lastName, HttpServletRequest
	 * request, HttpServletResponse response) { User user =
	 * userService.getUserByFirstnameAndLastname(firstName, lastName); return
	 * ResponseEntity.ok(user); }
	 */

	@GetMapping("/validatePathVariable/{id}")
	ResponseEntity<String> validatePathVariable(@PathVariable("id") @Min(5) int id) {
		return ResponseEntity.ok("valid");
	}

	@GetMapping("/validateRequestParameter")
	ResponseEntity<String> validateRequestParameter(@RequestParam("param") @Min(5) int param) {

		return ResponseEntity.ok("valid");
	}

}
