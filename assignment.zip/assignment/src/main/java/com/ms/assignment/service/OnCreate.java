package com.ms.assignment.service;

public interface OnCreate {
}
