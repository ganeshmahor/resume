package com.ms.assignment.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.ms.assignment.service.OnCreate;

@Entity
//@Table(name="USER")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull(message="User ID cannot be empty")
	private long id;
	
	@NotEmpty(message = "User First Name cannot be empty", groups = OnCreate.class)
	@Size(min = 2, max = 20)
	// @Column(name="firstname")
	private String firstName;
	
	@NotEmpty(message = "User Last Name cannot be empty", groups = OnCreate.class)
	@Size(min = 2, max = 20 , message="User Last Name must be equal or greater than 2 Characters and less than 20 characters")
	private String lastName;
	
	@NotEmpty(message = "User Email cannot be empty")
	@Email
	private String email;

	public User() {
		super();
	}

	public User(@NotNull(message = "User ID cannot be empty") int id,
			@NotEmpty(message = "User First Name cannot be empty") @Size(min = 2, max = 20) String firstName,
			@NotEmpty(message = "User Last Name cannot be empty") @Size(min = 2, max = 20, message = "User Last Name must be equal or greater than 2 Characters and less than 20 characters") String lastName,
			@NotEmpty(message = "User Email cannot be empty") @Email String email) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}



	public User(@NotEmpty(message = "User First Name cannot be empty") @Size(min = 2, max = 20) String firstName,
			@NotEmpty(message = "User Last Name cannot be empty") @Size(min = 2, max = 20, message = "User Last Name must be equal or greater than 2 Characters and less than 20 characters") String lastName,
			@NotEmpty(message = "User Email cannot be empty") @Email String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	public User(@NotNull(message = "User ID cannot be empty") int id,
			@NotEmpty(message = "User First Name cannot be empty") @Size(min = 2, max = 20) String firstName,
			@NotEmpty(message = "User Last Name cannot be empty") @Size(min = 2, max = 20, message = "User Last Name must be equal or greater than 2 Characters and less than 20 characters") String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	//Getters & Setters
	public long getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public boolean equals(Object o) { 

		// If the object is compared with itself then return true   
		if (o == this) { 
			return true; 
		} 

		// Check if o is an instance of Complex or not  "null instanceof [User]" also returns false 
		if (!(o instanceof User)) { 
			return false; 
		} 

		// Typecast o to User so that we can compare data members  
		User u = (User) o; 

		// Compare the data members and return accordingly  
		return Long.compare(id, u.id) == 0
				&& email.equals(u.email);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("User [id=");
		builder.append(id);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", email=");
		builder.append(email);
		builder.append("]");
		return builder.toString();
	}
}



/*
 *  CREATE TABLE user (`id` int NOT NULL AUTO_INCREMENT, 
	`first_name` varchar(20) NOT NULL,
    `last_name` varchar(20) NOT NULL, 
	`email` varchar(50) NOT NULL ,
	PRIMARY KEY (`id`), 
	UNIQUE(`email`)	
	);
 * 
 */


