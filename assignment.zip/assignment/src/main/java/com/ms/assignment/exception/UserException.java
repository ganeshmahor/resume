package com.ms.assignment.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * NOT FOUND
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class UserException extends RuntimeException {

	private static final long serialVersionUID = 1654367998775513762L;

	
	public UserException() {
		super();
	}

	public UserException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserException(String message) {
		super(message);
	}

	public UserException(Throwable cause) {
		super(cause);
	}

}
