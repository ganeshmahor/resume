package com.ms.assignment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.PathResourceResolver;
import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;

@Configuration
@EnableWebMvc
public class MvcConfig implements WebMvcConfigurer {

	
	/*
	 * <bean id="freemarkerConfig" class="org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer">
   			<property name="templateLoaderPath"><value>/WEB-INF/freemarker/</value></property>
 		</bean>
	 * 
	 */
	
	 @Override
	    public void addResourceHandlers(ResourceHandlerRegistry registry) {
	        System.out.println("WebMvcConfigurer - addResourceHandlers() function get loaded...");
	        registry.addResourceHandler("/resources/static/**")
	                .addResourceLocations("/resources/");

	        registry
	            .addResourceHandler("/js/**")
	            .addResourceLocations("/js/")
	            .setCachePeriod(3600)
	            .resourceChain(true)
	            .addResolver(new PathResourceResolver());
	    }

	 @Bean
	    public FreeMarkerViewResolver freemarkerViewResolver() {
	        
	        FreeMarkerViewResolver resolver = new FreeMarkerViewResolver();
	        
	        resolver.setCache(false);
	        resolver.setSuffix(".ftl");
	        
	        return resolver;
	    }

	
}