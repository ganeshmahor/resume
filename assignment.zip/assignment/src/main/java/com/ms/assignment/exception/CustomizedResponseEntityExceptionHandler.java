package com.ms.assignment.exception;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
@RestController
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handlseAllExceptions(Exception ex, WebRequest request) {
        List<String> details = new ArrayList<>();
        details.add(ex.getMessage());
        ErrorDetails error = new ErrorDetails(new Date(),"Server Error", details);
        //ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(),	request.getDescription(false));
        return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
 
	  @ExceptionHandler(UserException.class)
	public final ResponseEntity<Object> handleUserException(UserException ex, WebRequest request) {
	        List<String> details = new ArrayList<>();
	        details.add(ex.getMessage());
		ErrorDetails error = new ErrorDetails(new Date(), "Data Error", details);
	        return new ResponseEntity(error, HttpStatus.NOT_FOUND);
	    }

	@ExceptionHandler(OrderException.class)
	public final ResponseEntity<Object> handleOrderException(OrderException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		ErrorDetails error = new ErrorDetails(new Date(), "Data Error", details);
		return new ResponseEntity(error, HttpStatus.NOT_FOUND);
	}
	 

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<Object> handleUserNotFoundException(RecordNotFoundException ex, WebRequest request) {
		 List<String> details = new ArrayList<>();
	        details.add(ex.getMessage());
	        ErrorDetails error = new ErrorDetails(new Date(),"Record Not Found", details);
	        return new ResponseEntity(error, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(ResourceNotFoundException.class)
	public final ResponseEntity<Object> handleUserNotFoundException(ResourceNotFoundException ex, WebRequest request) {
		 List<String> details = new ArrayList<>();
	        details.add(ex.getMessage());
	        ErrorDetails error = new ErrorDetails(new Date(),"Resource Not Found", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}



@Override
protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
		HttpHeaders headers, HttpStatus status, WebRequest request) {
	 List<String> details = new ArrayList<>();
     for(ObjectError error : ex.getBindingResult().getAllErrors()) {
         details.add(error.getDefaultMessage());
     }
	ErrorDetails errorDetails = new ErrorDetails(new Date(), "Validation Failed",
			details);
	return new ResponseEntity<Object>(errorDetails, HttpStatus.BAD_REQUEST);
}

	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	ResponseEntity<Object> onConstraintValidationException(ConstraintViolationException e) {
		ValidationErrorResponse error = new ValidationErrorResponse();

		List<String> details = new ArrayList<>();

		for (ConstraintViolation violation : e.getConstraintViolations()) {
			// error.getViolations().add(new
			// Violation(violation.getPropertyPath().toString(), violation.getMessage()));
			details.add(violation.getPropertyPath().toString() + " - " + violation.getMessage());
		}

		ErrorDetails errorDetails = new ErrorDetails(new Date(), "Validation Failed", details);
		return new ResponseEntity<Object>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	/*
	 * @ExceptionHandler(ConstraintViolationException.class)
	 * 
	 * @ResponseStatus(HttpStatus.BAD_REQUEST)
	 * 
	 * @ResponseBody String
	 * handleConstraintViolationException(ConstraintViolationException e) {
	 * 
	 * return "not valid due to validation error: " + e.getMessage(); }
	 */

/*@ExceptionHandler(MethodArgumentNotValidException.class)
@ResponseStatus(HttpStatus.BAD_REQUEST)
@ResponseBody
ValidationErrorResponse onMethodArgumentNotValidException(
    MethodArgumentNotValidException e) {
  ValidationErrorResponse error = new ValidationErrorResponse();
  for (FieldError fieldError : e.getBindingResult().getFieldErrors()) {
    error.getViolations().add(
      new Violation(fieldError.getField(), fieldError.getDefaultMessage()));
  }
  return error;
}*/

/*@ExceptionHandler
@ResponseBody
@ResponseStatus(HttpStatus.BAD_REQUEST)
public Map handle(MethodArgumentNotValidException exception) {
    return error(exception.getBindingResult().getFieldErrors()
            .stream()
            .map(FieldError::getDefaultMessage)
            .collect(Collectors.toList()));
}


@ExceptionHandler
@ResponseBody
@ResponseStatus(HttpStatus.BAD_REQUEST)
public Map handle(ConstraintViolationException exception) {
    return error(exception.getConstraintViolations()
            .stream()
            .map(ConstraintViolation::getMessage)
            .collect(Collectors.toList()));
}

private Map error(Object message) {
    return Collections.singletonMap("error", message);
}*/



	
}