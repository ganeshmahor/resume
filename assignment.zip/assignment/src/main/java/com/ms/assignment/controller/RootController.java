package com.ms.assignment.controller;

import javax.ws.rs.GET;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class RootController {
	@RequestMapping(value="/helloworld")
	String helloWorld() {
		System.out.println("helloworld");
		return "Hello world";
	}
}
