package com.ms.assignment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ms.assignment.domain.Order;
import com.ms.assignment.domain.User;
import com.ms.assignment.exception.ErrorDetails;

@Configuration
public class AppConfig {

	@Bean
	public User user() {
		User obj = new User();
		return obj;
	}

	@Bean
	public Order order() {
		Order obj = new Order();
		return obj;
	}

	@Bean
	    public ErrorDetails errorDetails() {
		 ErrorDetails obj= new ErrorDetails(null, null, null);
	        return obj;
	    }
	 
	/*
	 * @Bean CommandLineRunner runner(UserRepository repository) { return args -> {
	 * repository.save(new User("Ganesh", "Mahor", "ganesh@gamil.com"));
	 * 
	 * };
	 * 
	 * }
	 * 
	 * @Bean(name = "updateRunner") CommandLineRunner updateRunner(UserRepository
	 * repository) { return args -> { repository.save(new User(1, "ABC", "XYZ",
	 * "abc@yyy.com"));
	 * 
	 * };
	 * 
	 * }
	 */

}
