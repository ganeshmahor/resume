package com.ms.assignment.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * NOT FOUND
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class OrderException extends RuntimeException {

	private static final long serialVersionUID = 1654367998775513762L;

	
	public OrderException() {
		super();
	}

	public OrderException(String message, Throwable cause) {
		super(message, cause);
	}

	public OrderException(String message) {
		super(message);
	}

	public OrderException(Throwable cause) {
		super(cause);
	}

}
