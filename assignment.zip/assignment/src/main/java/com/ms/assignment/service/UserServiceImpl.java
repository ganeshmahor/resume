package com.ms.assignment.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.assignment.dao.UserRepository;
import com.ms.assignment.domain.User;
import com.ms.assignment.exception.UserException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User getUserById(Long id) {
		Optional<User> user=userRepository.findById(id);
		if (!user.isPresent())
			throw new UserException("User Not Found for id=" + id);
		return user.get();
	}

	@Override
	public User createUser(User inUser) {
		StringBuilder builder = new StringBuilder();
		boolean createUserFlag = true;

		
		/*Optional<User> userid = userRepository.findById(inUser.getId());
		if (userid.isPresent()) {
			builder.append("User Already exist for id=" + inUser.getId());
			createUserFlag = false;
		}
		Optional<User> useremail = userRepository.findByEmail(inUser.getEmail());
		if (userid.isPresent()) {
			builder.append("User Already exist for Email=" + inUser.getEmail());
			createUserFlag = false;
		}*/

		if (userRepository.existsById(inUser.getId())) {
			builder.append("User Already exist for id=" + inUser.getId());
			createUserFlag = false;
		}

		if (userRepository.existsByEmail(inUser.getEmail())) {
			builder.append("\nUser Already exist for Email=" + inUser.getEmail());
			createUserFlag = false;
		}
		
		if (!createUserFlag)
			throw new UserException(builder.toString());
		User result = userRepository.save(inUser);
		return result;
	}

	@Override
	public User updateUser(User user) {
		User result = userRepository.save(user);
		return result;
	}

	@Override
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}

	@Override
	public User getUserByFirstnameAndLastname(String firstName, String lastName) {
		Optional<User> user = userRepository.findByFirstNameAndLastName(firstName, lastName);
		if (!user.isPresent())
			throw new UserException("User Not Found for First Name=" + firstName + " Last Name=" + lastName);
		return user.get();
	}

	@Override
	public User getUserByEmail(String email) {
		Optional<User> user = userRepository.findByEmail(email);
		if (!user.isPresent())
			throw new UserException("User Not Found for Email=" + email);
		return user.get();
	}

}
