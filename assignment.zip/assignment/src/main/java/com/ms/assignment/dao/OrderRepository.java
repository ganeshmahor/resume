package com.ms.assignment.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ms.assignment.domain.Order;

@Repository
public interface OrderRepository extends CrudRepository<Order, Long> {

	void deleteByUserId(Long id);

	Iterable<Order> findAllByUserId(Long id);

	/*
	 * @Override List<Order> findAll();
	 */

}

//User getUserByFirstnameAndLastname(String firstName, String lastName);

//User getUserByEmail(String email);
