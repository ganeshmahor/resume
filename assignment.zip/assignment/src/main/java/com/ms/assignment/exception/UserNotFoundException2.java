package com.ms.assignment.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * NOT FOUND
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class UserNotFoundException2 extends RuntimeException {

	private static final long serialVersionUID = 1654367998775513762L;

	
	public UserNotFoundException2() {
		super();
	}

	public UserNotFoundException2(String message, Throwable cause) {
		super(message, cause);
	}

	public UserNotFoundException2(String message) {
		super(message);
	}

	public UserNotFoundException2(Throwable cause) {
		super(cause);
	}

}
