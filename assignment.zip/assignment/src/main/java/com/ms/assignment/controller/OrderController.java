package com.ms.assignment.controller;

import java.net.URI;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ms.assignment.domain.Order;
import com.ms.assignment.service.OnCreate;
import com.ms.assignment.service.OrderServiceImpl;

@RestController
@RequestMapping("/order")
@Validated
public class OrderController {

	private @Autowired OrderServiceImpl orderService;

	@Validated(OnCreate.class)
	@PostMapping(value = "/", produces = { MediaType.APPLICATION_JSON_UTF8_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Object> createOrder(@Valid @RequestBody Order inOrder, HttpServletRequest request,
			HttpServletResponse response) {

		Order order = orderService.createOrder(inOrder);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(order.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}


	@PutMapping(value = "/", produces = { MediaType.APPLICATION_JSON_UTF8_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<Object> updateOrder(@Valid @RequestBody Order inOrder, HttpServletRequest request,
			HttpServletResponse response) {
		Order order = orderService.updateOrder(inOrder);
		return ResponseEntity.accepted().build();
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable("id") @Min(5) long id, HttpServletRequest request,
			HttpServletResponse response) {

		return ResponseEntity.noContent().build();
	}

	/*
	 * @GetMapping(value = "/{id}") public ResponseEntity<Object>
	 * getUserById(@PathVariable("id") @Min(1) long id, HttpServletRequest request,
	 * HttpServletResponse response) { User user = userService.getUserById(id);
	 * return ResponseEntity.ok(user);
	 * 
	 * }
	 * 
	 * @GetMapping(value = "/email/{email}") public ResponseEntity<Object>
	 * getUserByEmail(@PathVariable("email") @Email String email, HttpServletRequest
	 * request, HttpServletResponse response) { User user =
	 * userService.getUserByEmail(email); return ResponseEntity.ok(user); }
	 * 
	 * @GetMapping(value = "/name/{firstName}/{lastName}") public
	 * ResponseEntity<Object>
	 * getUserByFirstNameAndLastName(@PathVariable("firstName") @NotEmpty String
	 * firstName,
	 * 
	 * @PathVariable("lastName") @NotEmpty String lastName, HttpServletRequest
	 * request, HttpServletResponse response) { User user =
	 * userService.getUserByFirstnameAndLastname(firstName, lastName); return
	 * ResponseEntity.ok(user); }
	 */



}
