package com.ms.assignment.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
//@Table(name="ORDER")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull(message = "Order Id cannot be empty")
	private long id;

	@NotNull(message = "User Id cannot be empty")
	private int userId;
	private float amount;
	private String detail;
	
	public long getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public float getAmount() {
		return amount;
	}


	public void setAmount(float amount) {
		this.amount = amount;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}





	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Order [id=");
		builder.append(id);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", amount=");
		builder.append(amount);
		builder.append(", detail=");
		builder.append(detail);
		builder.append("]");
		return builder.toString();
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(amount);
		result = prime * result + ((detail == null) ? 0 : detail.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + userId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (Float.floatToIntBits(amount) != Float.floatToIntBits(other.amount))
			return false;
		if (detail == null) {
			if (other.detail != null)
				return false;
		} else if (!detail.equals(other.detail))
			return false;
		if (id != other.id)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	} 
	
}



/*
 *  CREATE TABLE `order` (`id` int NOT NULL AUTO_INCREMENT,
	`user_id` int NOT NULL,
    `amount` float NOT NULL, 
	`detail` varchar(200) NOT NULL, 
	PRIMARY KEY (`id`),
	CONSTRAINT FK_UserOrder_DEL FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) 
	ON DELETE CASCADE ON UPDATE CASCADE
	);

 * 
 */


