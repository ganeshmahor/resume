package com.ms.assignment.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ms.assignment.domain.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	Optional<User> findByFirstNameAndLastName(String firstName, String lastName);

	Optional<User> findByEmail(String email);

	boolean existsByEmail(String email);
}

//User getUserByFirstnameAndLastname(String firstName, String lastName);

//User getUserByEmail(String email);
