package com.ms.assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.assignment.dao.OrderRepository;
import com.ms.assignment.domain.Order;
import com.ms.assignment.exception.OrderException;
import com.ms.assignment.exception.RecordNotFoundException;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Override
	public Order createOrder(Order inOrder) {
		StringBuilder builder = new StringBuilder();
		if (orderRepository.existsById(inOrder.getId())) {
			builder.append("User Already exist for id=" + inOrder.getId());
			throw new OrderException(builder.toString());
		}
		Order result = orderRepository.save(inOrder);
		return result;
	}

	@Override
	public void deleteOrderById(Long id) {
		orderRepository.deleteById(id);
	}

	@Override
	public void deleteOrderByUserId(Long userId) {
		orderRepository.deleteByUserId(userId);
	}

	@Override
	public Order getOrderById(Long id) {
		Optional<Order> result = orderRepository.findById(id);
		if (!result.isPresent())
			throw new OrderException("Order Not Found for id=" + id);
		return result.get();
	}

	@Override
	public List<Order> getOrderByUserId(Long userId) {
		Iterable<Order> iter = orderRepository.findAllByUserId(userId);
		List<Order> list = new ArrayList<Order>();
		for (Order item : iter) {
			list.add(item);
		}
		if (list.isEmpty())
			throw new RecordNotFoundException("No Order data for user id=" + userId);
		return list;
	}

	@Override
	public Order updateOrder(Order inOrder) {
		StringBuilder builder = new StringBuilder();
		if (orderRepository.existsById(inOrder.getId())) {
			builder.append("User Already exist for id=" + inOrder.getId());
			throw new OrderException(builder.toString());
		}
		Order result = orderRepository.save(inOrder);
		return result;
	}
}
